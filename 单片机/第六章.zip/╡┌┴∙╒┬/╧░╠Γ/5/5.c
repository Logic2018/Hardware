#include<reg51.h>
sbit P1_0=P1^0;
void main(){
	TMOD=0x01;			 
	TR0=1;					 
	while(1){
		TH0=0xff;			 
		TL0=0x00;
		while(!TF0);	 
		P1_0=!P1_0;		 
		TF0=0;				 
	}
}
