
#include<reg51.h>
unsigned int i=0;
unsigned int k=-1;
unsigned char code L[]={0x01,0x04,0x02};   
unsigned int code time[]={4000,5000,1000};  
//unsigned int t=1000;		1ms x 1000 =1s
void delay(unsigned int t){
	TMOD=0x10;	
	TR1=1;
	while(1){
	TH1=-1000/256;	//1ms
	TL1=-1000%256;
	do{}while(!TF1);
	if(++i%t==0)		
		break;
	TF1=0;
	}
}
void main(){
	EA=1;		//�����ж�
	ET1=1;	//�򿪶�ʱ��T0�ж�
 while(1){
		P2=L[++k%3];
		delay(time[++k%3]);
	}
}

